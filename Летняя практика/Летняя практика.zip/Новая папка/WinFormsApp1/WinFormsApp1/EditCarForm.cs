﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class EditCarForm : Form
    {
        private string databaseFilePath; // Путь к файлу базы данных
        private List<Car> cars; // Список машин

        // Новый конструктор, который принимает список машин и путь к файлу
        public EditCarForm(List<Car> cars, string databaseFilePath)
        {
            InitializeComponent();
            this.cars = cars;
            this.databaseFilePath = databaseFilePath; // Сохраняем путь к файлу
        }

        private void EditCarForm_Load(object sender, EventArgs e)
        {
            LoadCarsToComboBox();
        }

        private void LoadCarsToComboBox()
        {
            // Загружаем машины из файла в comboBox
            if (File.Exists(databaseFilePath))
            {
                var lines = File.ReadAllLines(databaseFilePath);
                foreach (var line in lines)
                {
                    if (line.StartsWith("Car #"))
                    {
                        // Получаем номер машины
                        string carNumber = line.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries)[0];

                        // Получаем остальные характеристики
                        string brand = lines[Array.IndexOf(lines, line) + 1].Split(':')[1].Trim();
                        string country = lines[Array.IndexOf(lines, line) + 2].Split(':')[1].Trim();
                        string year = lines[Array.IndexOf(lines, line) + 3].Split(':')[1].Trim();
                        string isNew = lines[Array.IndexOf(lines, line) + 4].Split(':')[1].Trim();
                        string price = lines[Array.IndexOf(lines, line) + 5].Split(':')[1].Trim();
                        string quantity = lines[Array.IndexOf(lines, line) + 6].Split(':')[1].Trim();

                        // Формируем строку для отображения в comboBox
                        string displayText = $"{carNumber} - {brand}, {country}, {year}, {(isNew == "1" ? "Новая" : "Б/у")}, {price} руб., {quantity} шт.";
                        comboBoxCar.Items.Add(displayText);
                    }
                }
            }
            else
            {
                MessageBox.Show("Файл базы данных не найден.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnChangeCar_Click(object sender, EventArgs e)
        {
            // Проверка на корректность ввода данных
            if (!ValidateInputs())
            {
                return;
            }

            // Получаем данные из текстовых полей
            string carNumber = textBoxNumberCar.Text.Trim();
            string brand = textBoxMark.Text;
            string country = textBoxCountry.Text;
            int year = int.Parse(textBoxYear.Text);
            bool isNew = radioButtonNew.Checked;
            decimal price = decimal.Parse(textBoxPrice.Text);
            int quantity = int.Parse(textBoxQuantity.Text);

            // Создаем новую строку для обновленной машины
            string updatedCar = $"Car #{carNumber}\nBrand: {brand}\nCountry: {country}\nYear: {year}\nNew or Used: {(isNew ? "1" : "0")}\nPrice: {price}\nQuantity: {quantity}";

            // Обновляем данные в файле
            if (UpdateCarData(carNumber, updatedCar))
            {
                MessageBox.Show("Данные машины успешно обновлены!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close(); // Закрыть форму после изменения
            }
            else
            {
                MessageBox.Show("Машина с таким номером не найдена.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateInputs()
        {
            // Проверка на корректность ввода данных
            if (string.IsNullOrWhiteSpace(textBoxMark.Text) ||
                string.IsNullOrWhiteSpace(textBoxCountry.Text) ||
                !int.TryParse(textBoxYear.Text, out int year) ||
                year < 1886 || year > DateTime.Now.Year ||
                !decimal.TryParse(textBoxPrice.Text, out decimal price) ||
                price < 0 ||
                !int.TryParse(textBoxQuantity.Text, out int quantity) ||
                quantity < 0)
            {
                MessageBox.Show("Пожалуйста, проверьте введенные данные.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private bool UpdateCarData(string carNumber, string updatedCar)
        {
            // Читаем все данные из файла
            string[] allCars = File.ReadAllLines(databaseFilePath);
            var updatedCarsList = new List<string>();
            bool carFound = false;

            for (int i = 0; i < allCars.Length; i++)
            {
                // Если нашли машину, заменяем её на обновленные данные
                if (allCars[i].StartsWith($"Car #{carNumber}"))
                {
                    updatedCarsList.Add(updatedCar);
                    carFound = true;

                    // Пропускаем следующие строки, которые относятся к этой машине
                    i += 6; // Пропускаем 6 строк, так как у нас 6 строк для каждой машины
                }
                else
                {
                    updatedCarsList.Add(allCars[i]);
                }
            }

            if (carFound)
            {
                // Записываем обновленные данные обратно в файл
                File.WriteAllLines(databaseFilePath, updatedCarsList);
                return true; // Успешно обновлено
            }

            return false; // Не найдено
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close(); // Закрыть форму без изменений
        }
    }
}
