﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using WinFormsApp1;
using System.Globalization;

namespace CarManagementApp
{
    public partial class Menu : Form
    {
        private List<Car> cars; // Список машин
        private string filePath = "bd_cars.txt"; // Путь к файлу

        public Menu()
        {
            InitializeComponent();
            cars = LoadCarsFromFile(filePath); // Загрузка данных при инициализации
        }

        private List<Car> LoadCarsFromFile(string filePath)
        {
            var carList = new List<Car>();
            try
            {
                // Чтение файла
                var lines = File.ReadAllLines(filePath);
                Car? currentCar = null;

                foreach (var line in lines)
                {
                    if (line.StartsWith("Car #")) // Если строка начинается с "Car #", создаем новый объект Car
                    {
                        if (currentCar != null) // Если текущая машина не null, добавляем ее в список
                        {
                            carList.Add(currentCar);
                        }

                        // Извлечение номера машины из строки
                        currentCar = new Car();
                        string carNumberString = line.Substring(5).Trim(); // Получаем номер после "Car #"
                        if (int.TryParse(carNumberString, out int carNumber))
                        {
                            currentCar.CarNumber = carNumber; // Устанавливаем порядковый номер
                        }
                    }
                    else if (currentCar != null) // Если текущая машина и строка не начинается с "Car #"
                    {
                        // Обработка остальных строк
                        if (line.StartsWith("Brand:"))
                        {
                            currentCar.Brand = line.Substring(6).Trim();
                        }
                        else if (line.StartsWith("Country:"))
                        {
                            currentCar.Country = line.Substring(8).Trim();
                        }
                        else if (line.StartsWith("Year:"))
                        {
                            currentCar.Year = int.Parse(line.Substring(5).Trim());
                        }
                        else if (line.StartsWith("New or Used:"))
                        {
                            currentCar.NewOrUsed = int.Parse(line.Substring(12).Trim());
                        }
                        else if (line.StartsWith("Price:"))
                        {
                            currentCar.Price = float.Parse(line.Substring(6).Trim(), CultureInfo.InvariantCulture);
                        }
                        else if (line.StartsWith("Quantity:"))
                        {
                            currentCar.Quantity = int.Parse(line.Substring(9).Trim());
                        }
                    }
                }

                // Добавление последней машины в список, если она существует
                if (currentCar != null)
                {
                    carList.Add(currentCar);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
            return carList;
        }

        private void SaveCarsToFile(string filePath)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    foreach (var car in cars)
                    {
                        writer.WriteLine($"Car #{car.CarNumber}");
                        writer.WriteLine($"Brand: {car.Brand}");
                        writer.WriteLine($"Country: {car.Country}");
                        writer.WriteLine($"Year: {car.Year}");
                        writer.WriteLine($"New or Used: {car.NewOrUsed}");
                        writer.WriteLine($"Price: {car.Price}");
                        writer.WriteLine($"Quantity: {car.Quantity}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении данных: {ex.Message}");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var addForm = new AddCarForm(cars);
            if (addForm.ShowDialog() == DialogResult.OK) // Если форма закрыта с OK
            {
                SaveCarsToFile(filePath); // Сохранение изменений в файл
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            var editForm = new EditCarForm(cars, filePath); // Передаем список машин и путь к файлу
            if (editForm.ShowDialog() == DialogResult.OK) // Если форма закрыта с OK
            {
                SaveCarsToFile(filePath); // Сохранение изменений в файл
            }
        }


        private void btnSearch_Click(object sender, EventArgs e)
        {
            var searchForm = new SearchCarForm(cars); // Передача списка машин
            searchForm.ShowDialog();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var deleteForm = new DeleteCarForm(cars);
            if (deleteForm.ShowDialog() == DialogResult.OK) // Если форма закрыта с OK
            {
                SaveCarsToFile(filePath); // Сохранение изменений в файл
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // Логика для кнопки выхода
            this.Close();
        }
    }

    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Menu());
        }
    }
}
