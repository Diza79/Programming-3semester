﻿using System;
using System.Collections.Generic;
using System.IO; // Для работы с файлами
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class AddCarForm : Form
    {
        private List<Car> cars; // Список машин, переданный из меню
        private const string databaseFilePath = "bd_cars.txt"; // Путь к файлу базы данных

        public AddCarForm(List<Car> cars)
        {
            InitializeComponent();
            this.cars = cars; // Инициализируем список машин
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Проверяем, заполнены ли все поля
            if (string.IsNullOrWhiteSpace(textYear.Text) ||
                string.IsNullOrWhiteSpace(textStrana.Text) ||
                string.IsNullOrWhiteSpace(textMarka.Text) ||
                string.IsNullOrWhiteSpace(textPrice.Text) ||
                string.IsNullOrWhiteSpace(textQuantity.Text))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Переменные для хранения преобразованных значений
            int year;
            float price; // Изменяем тип на float
            int quantity;
            int newOrUsed; // Переменная для новой или б/у машины

            // Безопасное преобразование для года
            if (!int.TryParse(textYear.Text, out year))
            {
                MessageBox.Show("Введите корректный год.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Безопасное преобразование для цены
            if (!float.TryParse(textPrice.Text, out price))
            {
                MessageBox.Show("Введите корректную цену.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Безопасное преобразование для количества
            if (!int.TryParse(textQuantity.Text, out quantity))
            {
                MessageBox.Show("Введите корректное количество.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Устанавливаем значение для NewOrUsed в зависимости от выбранной радио-кнопки
            newOrUsed = rarbtnNew.Checked ? 1 : 0;

            // Создаем новую машину
            Car newCar = new Car
            {
                Brand = textMarka.Text,
                Country = textStrana.Text,
                Year = year,
                NewOrUsed = newOrUsed, // Присваиваем 1 или 0
                Price = price, // Присваиваем значение типа float
                Quantity = quantity
            };

            // Сохраняем новую машину в файл
            SaveCarToDatabase(newCar);

            // Добавляем новую машину в список
            cars.Add(newCar);
            MessageBox.Show("Машина успешно добавлена.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Закрываем форму
            this.Close();
        }

        private void SaveCarToDatabase(Car car)
        {
            // Определяем порядковый номер машины
            int carNumber = GetNextCarNumber();

            // Форматируем строку для записи в файл
            string carData = $"Car #{carNumber}\n" +
                             $"Brand: {car.Brand}\n" +
                             $"Country: {car.Country}\n" +
                             $"Year: {car.Year}\n" +
                             $"New or Used: {car.NewOrUsed}\n" +
                             $"Price: {car.Price}\n" +
                             $"Quantity: {car.Quantity}\n";

            // Записываем данные в файл
            File.AppendAllText(databaseFilePath, carData);
        }

        private int GetNextCarNumber()
        {
            int carCount = 0;

            // Проверяем, существует ли файл
            if (File.Exists(databaseFilePath))
            {
                var lines = File.ReadAllLines(databaseFilePath);
                foreach (var line in lines)
                {
                    // Ищем строки, начинающиеся с "Car #"
                    if (line.StartsWith("Car #"))
                    {
                        carCount++; // Увеличиваем счётчик для каждого найденного номера
                    }
                }
            }

            // Следующий номер будет равен количеству машин + 1
            return carCount + 1;
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            // Закрываем форму при нажатии кнопки "Отмена"
            this.Close();
        }
    }
}
