﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class DeleteCarForm : Form
    {
        private List<Car> cars; // Список машин, переданный из Menu
        private string filePath = "bd_cars.txt"; // Путь к файлу базы данных

        public DeleteCarForm(List<Car> cars)
        {
            InitializeComponent();
            this.cars = cars;

            // Проверка на наличие машин в базе данных
            if (cars.Count == 0)
            {
                MessageBox.Show("База данных пуста. Невозможно удалить машину.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close(); // Закрываем форму, если машин нет
                return;
            }

            // Заполнение ComboBox информацией о машинах
            UpdateComboBox();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Проверяем, выбрана ли машина
            if (comboBoxDel.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите машину для удаления.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Получаем индекс выбранной машины
            int selectedIndex = comboBoxDel.SelectedIndex;

            // Удаляем машину из списка
            cars.RemoveAt(selectedIndex);
            MessageBox.Show("Машина успешно удалена.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Обновляем порядковые номера и ComboBox
            UpdateCarNumbers();
            UpdateComboBox();

            // Обновляем файл базы данных
            SaveCarsToFile(filePath);
        }

        private void btnCancel_Click(object sender, EventArgs e) // Оставляем имя обработчика без изменений
        {
            this.Close(); // Закрываем форму
        }

        private void UpdateCarNumbers()
        {
            // Обновляем порядковые номера машин
            for (int i = 0; i < cars.Count; i++)
            {
                cars[i].CarNumber = i + 1; // Присваиваем новый номер
            }
        }

        private void UpdateComboBox()
        {
            comboBoxDel.Items.Clear();
            foreach (var car in cars)
            {
                // Формируем строку с полной информацией о машине
                string condition = car.NewOrUsed == 0 ? "Б/у" : "Новая"; // Предполагаем, что 1 - новая, 0 - б/у
                string displayText = $"№{car.CarNumber} - {car.Brand}, {car.Country}, {car.Year}, {condition}, {car.Price} руб., {car.Quantity} шт.";
                comboBoxDel.Items.Add(displayText);
            }
        }


        private void SaveCarsToFile(string filePath)
        {
            try
            {
                using (var writer = new StreamWriter(filePath))
                {
                    foreach (var car in cars)
                    {
                        writer.WriteLine($"Car #{car.CarNumber}");
                        writer.WriteLine($"Brand: {car.Brand}");
                        writer.WriteLine($"Country: {car.Country}");
                        writer.WriteLine($"Year: {car.Year}");
                        writer.WriteLine($"New or Used: {car.NewOrUsed}");
                        writer.WriteLine($"Price: {car.Price}");
                        writer.WriteLine($"Quantity: {car.Quantity}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении данных: {ex.Message}");
            }
        }
    }
}
