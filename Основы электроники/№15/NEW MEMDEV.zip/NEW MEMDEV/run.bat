@echo off
start java -jar MEMDEV.jar
