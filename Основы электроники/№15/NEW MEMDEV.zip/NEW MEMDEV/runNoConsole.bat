@echo off
start javaw -jar MEMDEV.jar
