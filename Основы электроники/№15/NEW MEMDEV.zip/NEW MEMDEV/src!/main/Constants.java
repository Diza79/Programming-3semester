package main;

/**
 * Всякие разные константы
 * @author uvarov
 * 
 */
public class Constants {
    
    static public String[] picturesLabel = {
        "Рисунок 0: 'Классификация запоминающих устройств'", "Рисунок 1: 'Структура запоминающего устройства'",
        "Рисунок 2: 'Фрагмент матрици интегрального ROM с диодами'", "Рисунок 3: 'Фрагмент матрици интегрального ROM с MOS-транзисторами'",
        "Рисунок 4: 'Фрагмент схемы прожигаемого PROM в счемотехнике TTL'", "Рисунок 5: 'Схемотехническая реализация одной из цепей PROM типа TTL'",
        "Рисунок 6: 'Структура одноразрядной LSI на MOS-транзисторах с плавающим затвором'", "Рисунок 7: 'Схема статического триггерного запоминающего устройства'",
        "Рисунок 8: 'Фрагмент схемы ЗУ с однотранзисторными элементаами'", "Рисунок 9: 'Структура одноразрядной LSI динамического ЗУ'"
    };

    static public String[] picturesFiles = {
        "pictures/picture0.html", "pictures/picture1.html",
        "pictures/picture2.html", "pictures/picture3.html",
        "pictures/picture4.html", "pictures/picture5.html",
        "pictures/picture6.html", "pictures/picture7.html",
        "pictures/picture8.html", "pictures/picture9.html"
    };
    
    static public String[] clasifInfo = {
        "Основные характеристики", "Классификация по способу хранения данных",
        "Классификация ОЗУ по режиму работы", "Классификация по технологии"
    };
    
    static public String[] clasifFiles = {
        "clasiffiles/clasif_part1.html", "clasiffiles/clasif_part2.html",
        "clasiffiles/clasif_part3.html", "clasiffiles/clasif_part4.html"
    };
    
    static public String[] ROMInfo = {
        "Классификация ROM", "Масочные и прожигаемые ЗУ",
        "Масочные PROM", "Прожигаемые PROM", "RPROM с УФ-стиранием",
        "RPROM с электрозаписью", "Электростатические RPROM"
    };
    
    static public String[] ROMFiles = {
        "romfiles/rom_part1.html", "romfiles/rom_part2.html", "romfiles/rom_part3.html", "romfiles/rom_part4.html",
        "romfiles/rom_part5.html", "romfiles/rom_part6.html", "romfiles/rom_part7.html"
    };
    
    static public String[] RAMInfo = {
        "Триггерные статические ЗУ", "Динамические ЗУ"
    };
    
    static public String[] RAMFiles = {
        "ramfiles/ram_part1.html", "ramfiles/ram_part2.html"
    };    
    
    static public String[] chipInfo = {
        "Характеристики", "Назначение выводов",
        "Структурная схема", "Таюлица истинности"
    };
    


//    К565РУ7
    static public String[] chipFiles1 = {
        "chipsfiles/chip1_part1.html", "chipsfiles/chip1_part2.html",
        "chipsfiles/chip1_part3.html", "chipsfiles/chip1_part4.html"
    };
    
//    КР537РУ14
    static public String[] chipFiles2 = {
        "chipsfiles/chip2_part1.html", "chipsfiles/chip2_part2.html",
        "chipsfiles/chip2_part3.html", "chipsfiles/chip2_part4.html"
    };    

//    К573РФ8
    static public String[] chipFiles3 = {
        "chipsfiles/chip3_part1.html", "chipsfiles/chip3_part2.html",
        "chipsfiles/chip3_part3.html", "chipsfiles/chip3_part4.html"
    };
    
//    КБ558РР3
    static public String[] chipFiles4 = {
        "chipsfiles/chip4_part1.html", "chipsfiles/chip4_part2.html",
        "chipsfiles/chip4_part3.html", "chipsfiles/chip4_part4.html"
    };
    
    static public String[] chipData1Title = {
        "Чтение", "Запись", "Слоговое чтение", "Слоговая запись", "Регенерация"
    };
    
    static public String[] chipData1Files = {
        "data/chip1/chip11.dat", "data/chip1/chip12.dat",
        "data/chip1/chip13.dat", "data/chip1/chip14.dat",
        "data/chip1/chip15.dat"
    };
    
    static public String[] chipData2Title = {
        "Чтение данных", "Запись данных"
    };
    
    static public String[] chipData2Files = {
        "data/chip2/chip21.dat", "data/chip2/chip22.dat"
    };    
    
    static public String[] chipData3Title = {
        "Чтение данных", "Программирование"
    };
    
    static public String[] chipData3Files = {
        "data/chip3/chip31.dat", "data/chip3/chip32.dat"
    };
    
    static public String[] chipData4Title = {
        "Чтение данных", "Занесение информации", "Стирание"
    };
    
    static public String[] chipData4Files = {
        "data/chip4/chip41.dat", "data/chip4/chip42.dat",
        "data/chip4/chip43.dat"
    };   
        
}
