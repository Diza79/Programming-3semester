package main;

import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;
import utils.Painter;

/**
 * Панель, на которой идет отрисовка одной временной диаграммы
 * @author uvarov
 */
public class MyPanel extends JPanel {

    int id;

    ShowDiagram parent = null;
    ShowDiagramTest parent2 = null;
    
    public void setId(int id) {
        this.id = id;
    }
    
    public int getId() {
        return id;
    }
    
    public void setParent(ShowDiagram parent) {
        this.parent = parent;
    }
    
        
    public void setParent(ShowDiagramTest parent) {
        this.parent2 = parent;
    }


    @Override
    public void paint(Graphics g) {
        super.paint(g);
        if (parent != null) {
            if (parent.diagrams != null) {
                if (id < parent.diagrams.length)
                    Painter.draw(parent.diagrams[id], this, parent.curX, (Graphics2D)g, true);
            }
        } 
        if (parent2 != null) {
            if (parent2.diagrams != null) {
                if (id < parent2.diagrams.length)
                    Painter.draw(parent2.diagrams[parent2.perm.get(id)], this, 1.0, (Graphics2D)g, false);
            }
        }
    }
    
    
}
