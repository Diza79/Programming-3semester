package utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;

/**
 *Класс для чтения диаграмм
 * @author uvarov
 */
public class DiagramReader {
    ObjectInputStream ois;
    
    public DiagramReader(InputStream stream) throws IOException {
        ois = new ObjectInputStream(stream);
    }
       
    public Diagram nextDiagram() throws IOException, ClassNotFoundException {
        return (Diagram) ois.readObject();
    }
    
    public int nextInt() throws IOException {
        return ois.readInt();
    }
    
    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        ois.close();
    }
    
    
    
}
