package utils;

import java.io.Serializable;

/**
 *
 * @author uvarov
 */
public class Segment  implements Serializable {
    public double k;
    public double b;
    public double x1;
    public double x2;

    public Segment(double k, double b, double x1, double x2) {
        this.k = k;
        this.b = b;
        this.x1 = x1;
        this.x2 = x2;
    }

    public boolean between(double x) {
        return x1 < x && x < x2;
    }
    
    public double getY(double x){
        return k * x + b;
    }

    @Override
    public String toString() {
        return "[" + k + ", " + b + ", " + x1 + ", " + x2 +"]";
    }
    
    
    
}
