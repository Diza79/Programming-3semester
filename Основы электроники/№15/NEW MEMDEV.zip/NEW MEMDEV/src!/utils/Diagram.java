package utils;

import java.io.Serializable;

/**
 *
 * @author uvarov
 */
public class Diagram implements Serializable {
    String label;
    public Segment[] segments;
    public double[] stopPoints;
    public String[] stopLabels;

    public Diagram(String label, Segment... segments) {
        this.label = label;
        this.segments = segments;
    }

    public Diagram(String string, Object[] toArray) {
        label = string;
        segments = new Segment[toArray.length];
        for (int i = 0; i < toArray.length; i++) {
            segments[i] = (Segment) toArray[i];
        }
    }
    
    public String getLabel() {
        return label;
    }

}
