package utils;

import javax.swing.JOptionPane;

/**
 *
 * @author uvarov
 */
public class ShowError {
    public static void showError(String text) {
        JOptionPane.showMessageDialog(null, text, "Ошибка", JOptionPane.ERROR_MESSAGE);
    }
}
