package utils;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JPanel;

/**
 *
 * @author uvarov
 */
public class Painter {
    
    static Color completColor = Color.WHITE;
    static Color notCompletColor  = new Color(0, 85, 85);
    static Color textColor = new Color(170, 170, 170);
    
    static double scaleX;
    static double scaleY;
    
    static double x0;
    static double y0;
    
    /**
     * Рисует заданную диаграмму на заданной форме
     * @param dg сама диаграмма
     * @param panel форма
     * @param curX текущее время во временной диаграмме
     * @param g на нем рисуется
     * @param showLabel true - если надо писать названия (при обучении), false - иначе
     */
    public static void draw(Diagram dg, JPanel panel, double curX, Graphics2D g, boolean showLabel) {
        RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

	g.setRenderingHints(rh);
        g.setStroke(new BasicStroke(1.0f));
        g.setColor(textColor);
        if (showLabel) {
            g.drawString(dg.getLabel(), 5, panel.getHeight() / 2);
        }
        g.setStroke(new BasicStroke(2.0f));
        int len = panel.getWidth() - 50 - 10 - 10;
        int h = panel.getHeight();
        int  y1 = (int) (h * 0.1);
        g.drawLine(50 + 10, y1, 50 + 10, h - y1);
        g.drawLine(50 + 10, h - y1, 50 + 10 + len, h - y1);
        
        y0 = (int) ((panel.getHeight() - 2 * y1) * 0.5 + y1);
        x0 = 50 + 10 + 1;
        scaleY = (h - 2 * y1) / 3.0;
        scaleX = len;
            g.setColor(Color.red);
        g.drawLine((int)0, 25, (int)(0 ), 56 + 15);
        for (Segment s : dg.segments) {
            drawSegment(s, g, curX);
        }        
    }
    
    /**
     * Получение координаты x на форме
     * @param x 
     * @return 
     */
    static int getX(double x) {
        return (int) (x0 + x * scaleX);
    }
    
    /**
     * Получение координаты y на форме
     * @param y
     * @return 
     */
    static int getY(double y) {
        return (int) (y0 - y * scaleY);
    }
    
    /**
     * Отрисовка сегмента
     * @param s сегмент
     * @param g на чем рисовать
     * @param curX время во временной диаграмме
     */
    private static void drawSegment(Segment s, Graphics2D g, double curX) {
        if (s.between(curX)) {
            g.setColor(completColor);
            g.drawLine(getX(s.x1), getY(s.getY(s.x1)), getX(curX), getY(s.getY(curX)));

            g.setColor(notCompletColor);
            g.drawLine(getX(curX), getY(s.getY(curX)), getX(s.x2), getY(s.getY(s.x2)));

        } else {
            if (s.x2 <= curX)
                g.setColor(completColor);
            else
                g.setColor(notCompletColor);
            g.drawLine(getX(s.x1), getY(s.getY(s.x1)), getX(s.x2), getY(s.getY(s.x2)));
        }
    }
}
